# -*- coding: utf-8 -*-
"""
Created on Sun Oct 30 19:53:26 2022

@author: USER
"""

from flask import Flask 
import os
from flask import request
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

app=Flask(__name__)

@app.route('/')
def uno():
    x=os.environ.get("Prueba")
    return x


@app.route('/e-mail')
def mail():
    
    destino=request.args.get("destino")
    asunto=request.args.get("asunto")
    cuerpo=request.args.get("contenido")
   
    message = Mail(
        from_email='luciana271897@gmail.com',
        to_emails=destino,
        subject=asunto,
        html_content=cuerpo)
    try:
        sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
        response = sg.send(message)
        print(response.status_code)
        print(response.body)
        print(response.headers)
        return "El correo ha sido enviado"
    except Exception as e:
        print(e.message)
    return "Error el mensaje no fue enviado"
if __name__=='__main__':
    app.run()

    
    