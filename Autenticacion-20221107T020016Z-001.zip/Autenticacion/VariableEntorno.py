# -*- coding: utf-8 -*-
"""
Created on Sun Oct 30 19:53:26 2022

@author: USER
"""

import os

os.environ["Prueba"]="Esta es una variable de entorno almacenada"

os.environ['SENDGRID_API_KEY']="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"